package uk.co.marcoratto.ant.util;

import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

public class Logger {

	private static Logger instance = null;
	private Task task = null;
	
	private Logger() {		
	}
	
	public static Logger getInstance() {
		if (instance == null) {
			instance = new Logger();
		}
		
		return instance;
	}
			
	public Task getTask() {
		return task;
	}

	public void setTask(Task task) {
		this.task = task;
	}

	public void error(Throwable t) {
		if (task == null) {
			t.printStackTrace();
		} else {
			task.log(t, Project.MSG_ERR);		
		}
	}
	   
	   public void error(String msg) {
		   if (task == null) {
				System.err.println(msg);
			} else {
				task.log(msg, Project.MSG_ERR);		
			}
	   }

	   public void warning(Throwable t) {
		   if (task == null) {
				t.printStackTrace();
			} else {
				task.log(t, Project.MSG_WARN);		
			}
	   }

	   public void warning(String msg) {
		   if (task == null) {
				System.err.println(msg);
			} else {
				task.log(msg, Project.MSG_WARN);		
			}
	   }
	   
	   public void debug(Throwable t) {
		   if (task == null) {
				t.printStackTrace();
			} else {
				task.log(t, Project.MSG_DEBUG);		
			}
	   }

	   public void debug(String msg) {
		   if (task == null) {
				System.err.println(msg);
			} else {
				task.log(msg, Project.MSG_DEBUG);		
			}
	   }
	   
	   public void info(Throwable t) {
		   if (task == null) {
				t.printStackTrace();
			} else {
				task.log(t, Project.MSG_INFO);		
			}
	   }

	   public void info(String msg) {
		   if (task == null) {
				System.err.println(msg);
			} else {
				task.log(msg, Project.MSG_INFO);		
			}
	   }
	   
	   public void verbose(Throwable t) {
		   if (task == null) {
				t.printStackTrace();
			} else {
				task.log(t, Project.MSG_VERBOSE);		
			}
	   }

	   public void verbose(String msg) {
		   if (task == null) {
				System.err.println(msg);
			} else {
				task.log(msg, Project.MSG_VERBOSE);		
			}
	   }
}
