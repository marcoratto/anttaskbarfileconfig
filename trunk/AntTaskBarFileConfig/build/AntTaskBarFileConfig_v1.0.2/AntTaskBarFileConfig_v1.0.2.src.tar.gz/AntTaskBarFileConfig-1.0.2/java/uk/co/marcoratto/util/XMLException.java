package uk.co.marcoratto.util;

@SuppressWarnings("serial")
public class XMLException extends Exception {

	public XMLException(Throwable t) {
		super(t);
	}

	public XMLException(Exception e) {
		super(e);
	}

	public XMLException(String msg) {
		super(msg);
	}
}
